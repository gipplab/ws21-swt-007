package application.Objects;

public abstract class Entities {

	public Entities() {
		// TODO Auto-generated constructor stub
	}

}
